package com.vibol;

public class LinkListApp {

	public static void main(String[] args) {

		LinkListDemo list = new LinkListDemo();
		list.append(10);
		list.append(20);
		list.append(30);
		
		
		list.addAtBegginning(5);
		
		list.addAtEnd(50);
		
		list.append(80);
		
		list.addAfter(30, 35);
		list.printList();
		
		list.deletedAtBeginning();
		list.printList();
		list.deletedAtEnd();
		list.printList();
		
		list.removeByValue(10);
		list.printList();
		
	}

}
